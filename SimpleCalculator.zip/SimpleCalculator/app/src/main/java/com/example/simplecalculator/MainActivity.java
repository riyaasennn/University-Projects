package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {

    TextView Num;
    Button Ac,Bc;
    int result=0;
    String str = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Num = findViewById(R.id.Number);
        Ac = findViewById(R.id.AC);
        Bc = findViewById(R.id.Backspace);



    }

    public void Clear(View v){

        for (int i=0;i<1;i++) {
            if (str.equals(""))
                break;
            if (v == Ac) {
                Num.setText("");
                str = "";
                result = 0;
            }
            if (v == Bc) {
                String txt = Num.getText().toString();
                txt = txt.substring(0, txt.length() - 1);
                Num.setText(txt);
                str = txt;
            }
        }

    }

    public void NumInsert(View v){

        switch (v.getId()){
            case R.id.Zero:
                str += "0";
                Num.setText(str);
                break;


            case R.id.One:
                str += "1";
                Num.setText(str);
                break;

            case R.id.Two:
                str += "2";
                Num.setText(str);
                break;

            case R.id.Three:
                str += "3";
                Num.setText(str);
                break;

            case R.id.Four:
                str += "4";
                Num.setText(str);
                break;

            case R.id.Five:
                str += "5";
                Num.setText(str);
                break;

            case R.id.Six:
                str += "6";
                Num.setText(str);
                break;

            case R.id.Seven:
                str += "7";
                Num.setText(str);
                break;

            case R.id.Eight:
                str += "8";
                Num.setText(str);
                break;

            case R.id.Nine:
                str += "9";
                Num.setText(str);
                break;

            case R.id.BracketOpen:
                str += "(";
                Num.setText(str);
                break;

            case R.id.BracketClose:
                String c = String.valueOf(str.charAt(str.length()-1));
                if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("^") || c.equals("!")) {
                    break;}
                str += ")";
                Num.setText(str);
                break;
        }

    }

    public void Operations(View v){

        for (int i=0;i<1;i++) {
            if (str.equals(""))
                break;
            String c = String.valueOf(str.charAt(str.length()-1));
            if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("^") || c.equals("!")) {
                break;}

            switch (v.getId()) {
                case R.id.Addition:
                    str += "+";
                    Num.setText(str);
                    break;

                case R.id.Subtraction:
                    str += "-";
                    Num.setText(str);
                    break;

                case R.id.Multiplication:
                    str += "*";
                    Num.setText(str);
                    break;

                case R.id.Division:
                    str += "/";
                    Num.setText(str);
                    break;

                case R.id.Power:
                    str += "^";
                    Num.setText(str);
                    break;

                case R.id.Factorial:

                    int a = Integer.parseInt(str),d=1;
                    for (int j = a;j>0;j--){
                        d*=j;
                    }
                    str = String.valueOf(d);
                    Num.setText(str);
                    break;

            }
        }

    }

    static int Prec(char ch)
    {
        switch (ch)
        {
            case '+':
            case '-':
                return 1;

            case '*':
            case '/':
                return 2;

            case '^':
                return 3;
        }
        return -1;
    }

    public String  infixToPostfix(String exp)
    {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i<exp.length(); i++)
        {
            char c = exp.charAt(i);
            if (Character.isLetterOrDigit(c)){
                result.append(c);
            }

            else if (c == '(')
                stack.push(c);

            else if (c == ')')
            {
                while (!stack.isEmpty() && stack.peek() != '(')
                    result.append(String.valueOf(stack.pop()));

                if (!stack.isEmpty() && stack.peek() != '(')
                    return "Invalid Expression";
                else
                    stack.pop();
            }
            else
            {
                while (!stack.isEmpty() && Prec(c) <= Prec(stack.peek())){
                    if(stack.peek() == '('){
                        return "Invalid Expression";}
                    result.append(String.valueOf(stack.pop()));
                }
                result.append(",");
                stack.push(c);
            }

        }
        while (!stack.isEmpty()){
            if(stack.peek() == '(')
                return "Invalid Expression";
            result.append(",");
            result.append(String.valueOf(stack.pop()));
        }
        return result.toString();
    }


    public void Result(View v) {

        for (int k = 0; k < 1; k++) {

            if (str.equals(""))
                    break;
            String w = String.valueOf(str.charAt(str.length()-1));
            if (w.equals("+") || w.equals("-") || w.equals("*") || w.equals("/") || w.equals("^") || w.equals("!")) {
                break;}
            String s = infixToPostfix(str);
            Num.setText(s);
            Stack<Integer> st = new Stack<>();
            int x, y;
            for (int i = 0; i < s.length(); i++) {
                char aCh = s.charAt(i);
                if (aCh >= '0' && aCh <= '9'){
                    x = 0;
                    while(s.charAt(i) >= '0' && s.charAt(i) <= '9'){
                        char t = s.charAt(i);
                        y = Integer.parseInt(String.valueOf(t));
                        x = x * 10 + y;
                        i++;
                    }
                    st.push(x);
                    i--;
                }
                else {
                    if(aCh==','){
                        continue;
                    }
                    x = st.pop();
                    y = st.pop();

                    switch (aCh) {
                        case '+':
                            st.push(x + y);
                            break;
                        case '-':
                            st.push(y - x);
                            break;
                        case '*':
                            st.push(x * y);
                            break;
                        case '/':
                            st.push(y / x);
                            break;
                        case '^':
                            int a=1;
                            while (x>0){
                                a *=y;
                                x--;
                            }
                            st.push(a);
                            break;
                    }

                }

            }
            int z = st.pop();
            str = String.valueOf(z);
            Num.setText(str);
        }
    }
}
